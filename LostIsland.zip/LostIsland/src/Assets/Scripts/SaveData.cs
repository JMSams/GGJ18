﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace FallingSloth.GGJ18
{
    public class SaveData : SaveManager.SaveData
    {
        public int highestWave = 0;
    }
}